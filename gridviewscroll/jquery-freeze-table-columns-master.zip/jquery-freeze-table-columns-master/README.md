jquery-freeze-table-columns
===========================

A JQuery plugin to freeze table columns and headers written by Conan Albrecht

Original post: http://warp.byu.edu/site/content/1020
Usage example:  http://eureka.ykyuen.info/2013/04/08/jquery-freeze-html-table-header-and-the-left-columns